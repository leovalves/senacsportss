/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.dao;

import java.sql.Connection;
import com.mycompany.classes.Cliente;
import java.sql.PreparedStatement;
import com.mycompany.view.TelaCadastroCliente;
import com.mycompany.view.TelaCliente;
import com.mysql.cj.x.protobuf.MysqlxPrepare;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Chagas
 */
public class ClienteDAO {
   public static String url = "jdbc:mysql://localhost:3306/db_senacsports";
   public static String login = "root";
   public static String senha = "";
  
 public void inserir(Cliente cliente){
      
     Connection conexao = null;
     String sql = "INSERT INTO cadastro_cliente(CPF, nome, endereco, email, sexo, fone, estado_civil, data_nascimento) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
      try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexao = DriverManager.getConnection(url, login, senha);
          PreparedStatement comandoSQL = conexao.prepareStatement(sql);
          comandoSQL.setString(1, cliente.getCpf());
          comandoSQL.setString(2, cliente.getNome());
          comandoSQL.setString(3, cliente.getEndereco());
          comandoSQL.setString(4, cliente.getEmail());
          comandoSQL.setString(5, cliente.getSexo());
          comandoSQL.setString(6, cliente.getFone());
          comandoSQL.setString(7, cliente.getEstado_civil());
          comandoSQL.setString(8, cliente.getData_nascimento());
          comandoSQL.execute();
     } catch (Exception e) {
          JOptionPane.showMessageDialog(null, "Erro ao cadastrar cliente: " + e.getMessage());
     }
      
 }
    public static Cliente consultar(String cpf){
            Cliente cliente = new Cliente();
            Connection conexao = null;
           
        try {
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexao = DriverManager.getConnection(url, login, senha);
        
            PreparedStatement comandoSQL = conexao.prepareStatement("SELECT * FROM cadastro_cliente WHERE CPF =?;");
            comandoSQL.setString(1, cpf);
            ResultSet rs = comandoSQL.executeQuery();
            if(rs != null){
                while(rs.next()){
          
            cliente.setCpf(rs.getString("CPF"));
            cliente.setNome(rs.getString("nome"));
            cliente.setEndereco(rs.getString("endereco"));
            cliente.setEmail(rs.getString("email"));
            cliente.setSexo(rs.getString("sexo"));
            cliente.setFone(rs.getString("fone"));
            cliente.setEstado_civil(rs.getString("estado_civil"));
            cliente.setData_nascimento(rs.getString("data_nascimento"));
        
                }
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao consultar cliente: " + e.getMessage());
           
        }
            return cliente;
    }
    public List<Cliente> listar(String cpf)
        {
           
             String sql = "Select * from cadastro_cliente WHERE cpf LIKE ?";
             Connection conexao = null;
            try {
             Class.forName("com.mysql.cj.jdbc.Driver");
             conexao = DriverManager.getConnection(url, login, senha);
             PreparedStatement comandoSQL = conexao.prepareStatement(sql);
             comandoSQL.setString(1, "%" + cpf + "%");
             ResultSet rs = comandoSQL.executeQuery();
             List<Cliente> listaCadastro_cliente = new ArrayList<>();
             //percore o rs e salva as infromaçoes dentro de uma variavel Cliente e dps salva essa variavel dentro da lista
             while(rs.next()){
            Cliente cliente = new Cliente();
            cliente.setCpf(rs.getString("CPF"));
            cliente.setNome(rs.getString("nome"));
            cliente.setEndereco(rs.getString("endereco"));
            cliente.setEmail(rs.getString("email"));
            cliente.setSexo(rs.getString("sexo"));
            cliente.setFone(rs.getString("fone"));
            cliente.setEstado_civil(rs.getString("estado_civil"));
            cliente.setData_nascimento(rs.getString("data_nascimento"));
            listaCadastro_cliente.add(cliente);
             }
             return listaCadastro_cliente;
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Erro ao consultar cliente: " + e.getMessage());
                return null;
            }
        }
    }

    

